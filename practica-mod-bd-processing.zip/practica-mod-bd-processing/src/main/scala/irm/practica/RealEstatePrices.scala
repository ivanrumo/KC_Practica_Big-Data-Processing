package irm.practica

import irm.practica.utils.Config
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import spire.macros.Auto.scala

object RealEstatePrices {
  def main(args: Array[String]): Unit = {



    // creamos el objeto Spark seccion
    val spark = SparkSession.builder
      .appName("Kafka Input")
      .master("local[*]")
      .getOrCreate

    // configuramos el nivel de traza
    Config.setupLogging()

    // Debemos importart spark.implicits paraque funcionen debidamente las conversiones
    import spark.implicits._

    // cargamos el csv con los datos de los precios de productos inmoviliarios
    val realEstateDF = spark.read
      .option("header",true)
      .option("sep",",")
      .option("inferschema",true)
      .csv(Config.pathRealEstateCSVFile)

    realEstateDF.printSchema()

    // creamos funciones UDF para limpiar y transformar los datos

    // con esta funcion haremos trim del campo Location
    val trimFieldUDF = udf[String, String]((e:String) => e.trim)
    // con esta funcion pasamos pies a metros
    val feetToMetersUDF = udf[Double, Double]((e:Double) => e / 10.764)
    // ahora vamos a hacer uns funcion para pasar el precio de euros a dolares.
    // primero obtemos el valor del cambio EUR -> USD con un API externa que nos proporciona el valor del cambio
    val usdRate = Config.getExchangeValue()
    // ahora creamos la udf para pasar los dolares a euros
    val usd2eurUDF = udf[Double, Double]((e:Double) => e * usdRate)

    // creamos un data frame con la localizacion trimeada, el tamaño de la vivienda en metros y el precio en EUR
    val realStateCleanedDF = realEstateDF.select(
      trimFieldUDF($"Location").as("Location"),
      feetToMetersUDF($"Size").as("Meters"),
      usd2eurUDF($"Price").as("PriceEUR"))
    realStateCleanedDF.show

    // ahora obtenemos un dataframe con la localidad y el precio por m2 en euros
    val realStateValuesDF = realStateCleanedDF.select(
      $"Location",
      ($"PriceEUR" / $"Meters").as("PriceMeter"))
    realStateValuesDF.show

    // creamos una tabla con el DF obtenido para hacer consultas SQL
    realStateValuesDF.createOrReplaceTempView("realStatePrices")
    // realizamos un SQL para obtener la media del precio medio del m2 por localidad
    val mediaPreciosDF = spark.sql("""SELECT Location, avg(PriceMeter)
                          FROM realStatePrices
                          GROUP BY Location
                          ORDER BY Location""")
    mediaPreciosDF.show(40)

    // procuramos que los datos se queden en una sola partición para que solo se genere un fichero de salida al guardar el dataframe
    val mediaPrecios1PartDF = mediaPreciosDF.coalesce(1)

    // guardamos el contenido del dataframe en formato json
    mediaPrecios1PartDF.write.json(Config.pathRealEstateAvgPricesByLocation)
  }
}
