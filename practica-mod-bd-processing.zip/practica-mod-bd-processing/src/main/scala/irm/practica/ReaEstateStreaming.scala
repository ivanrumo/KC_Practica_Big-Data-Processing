package irm.practica

import irm.practica.utils.Config
import org.apache.spark.sql.{ForeachWriter, Row, SparkSession}
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object ReaEstateStreaming {


  def main(args: Array[String]): Unit = {

    // obtenemos el precio limite sobre el que se evalua si se supera para crear una alarma

    var limite:Double = 7000
    if (args.length > 0) {
      limite = args(0).toInt
    }
println(limite)

    // creamos el objeto Spark seccion
    val spark = SparkSession.builder
      .appName("Kafka Input")
      .master("local[*]")
      .config("spark.sql.streaming.checkpointLocation", Config.pathRealEstatePricesChekpointStreaming)
      .getOrCreate

    // configuramos el nivel de traza
    Config.setupLogging()

    // creamos un esquema para los datos de entrada
    val schemaPrices = new StructType()
      .add("mls",IntegerType,true)
      .add("Location",StringType, true)
      .add("Price",DoubleType, true)
      .add("Bedrooms",IntegerType, true)
      .add("Bathrooms",IntegerType, true)
      .add("Size",IntegerType, true)
      .add("PriceSQFt",DoubleType, true)
      .add("Status",StringType, true)


    // indicamos el directorio sobre el que proceso tiene que estar escuchando
    val realEstateData = spark.readStream
        .option("header", "true")
        .schema(schemaPrices)
        .csv(Config.pathFolderStreaming)

    // Debemos importart spark.implicits paraque funcionen debidamente las conversiones
    import spark.implicits._


    // con esta funcion haremos trim del campo Location
    val trimFieldUDF = udf[String, String]((e:String) => e.trim)
    // con esta funcion pasamos pies a metros
    val feetToMetersUDF = udf[Double, Double]((e:Double) => e / 10.764)
    // ahora vamos a hacer uns funcion para pasar el precio de euros a dolares.
    // primero obtemos el valor del cambio EUR -> USD con un API externa que nos proporciona el valor del cambio
    val usdRate = Config.getExchangeValue()
    // ahora creamos la udf para pasar los dolares a euros
    val usd2eurUDF = udf[Double, Double]((e:Double) => e * usdRate)

    // creamos un data frame con la localizacion trimeada, el tamaño de la vivienda en metros y el precio en EUR
    val realStateCleanedDF = realEstateData.select(
      trimFieldUDF($"Location").as("Location"),
      feetToMetersUDF($"Size").as("Meters"),
      usd2eurUDF($"Price").as("PriceEUR"))
//    realStateCleanedDF.show

    // ahora obtenemos un dataframe con la localidad y el precio por m2 en euros
    val realStateValuesDF = realStateCleanedDF.select(
      $"Location",
      ($"PriceEUR" / $"Meters").as("PriceMeter"))
//    realStateValuesDF.show

    val dataSorted = realStateValuesDF.groupBy("Location").agg(avg("PriceMeter").alias("PriceMeterAvg"),count("Location")).orderBy(desc("PriceMeterAvg"))

    val pricesOverLimit = dataSorted.filter($"PriceMeterAvg" > limite)

    val query =  dataSorted.writeStream
        .outputMode("complete")
        .format("console")
        .start



    val query2 =  pricesOverLimit.writeStream
      .outputMode("complete")
      .format("console")
      .foreach(new ForeachWriter[Row] {

        override def process(row: Row): Unit = {
          println(s"Over limit ${row}")
          /*import utils.mail._
          send a new Mail(
            from = ("ivan.rmgi@gmail.com", "Alertas"),
            to = "ivan.rubio.moreno@gmail.com",
            subject = "Price Alert",
            message = s"Prices too high in ${row.getString(0)} "
          )*/
        }

        override def close(errorOrNull: Throwable): Unit = {}

        override def open(partitionId: Long, version: Long): Boolean = {
          true
        }
      })
      .start

    query.awaitTermination()
    query2.awaitTermination()

    spark.stop()
  }
}
