package irm.practica.fase2

import java.io.File

import irm.practica.utils.Utils
import irm.practica.utils.mail.send
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, StructType}
import org.apache.spark.sql.{ForeachWriter, Row, SaveMode, SparkSession}

object ReaEstateStreaming {


  def main(args: Array[String]): Unit = {
    // obtenemos el precio limite sobre el que se evalua si se supera para crear una alarma
    var limite:Double = 7000
    if (args.length > 0) {
      limite = args(0).toInt
    }
    
    // creamos el objeto Spark seccion
    val spark = SparkSession.builder
      .appName("ReaEstateStreaming")
      .master("local[*]")
      .config("spark.sql.streaming.checkpointLocation", Utils.pathRealEstatePricesChekpointStreaming)
      .getOrCreate

    // configuramos el nivel de traza
    Utils.setupLogging()

    // creamos un esquema para los datos de entrada
    val schemaPrices = new StructType()
      .add("Location",StringType, true)
      .add("Average_Price_Meter",DoubleType, true)

    // indicamos el directorio sobre el que proceso tiene que estar escuchando
    val realEstateData = spark.readStream
        .option("header", "true")
        .schema(schemaPrices)
        .json(Utils.pathRealEstateAvgPricesByLocation)

    // Debemos importart spark.implicits paraque funcionen debidamente las conversiones
    import spark.implicits._


    val windowDF = realEstateData.groupBy($"Location", $"Average_Price_Meter", window(current_timestamp(), "1 hour"))
      .count()
      .orderBy($"Average_Price_Meter".desc)

    // iniciamos procedimiento query y mostra el resultado por consola de modo 'complete'
    val query =  windowDF.writeStream
      .outputMode("complete")
      .format("console")
      .start

    // en este otro dataframe windowDF las localidades donde el precio medio ha subido por encima del límite
    val pricesOverLimit = windowDF.filter($"Average_Price_Meter" > limite)

    // iniciamos procedimiento queryLimit y realizamos un bucle por cada fila obtenida para mostrar que localidades han superado el limite
    // y mandamos un correo de alerta al departamento correspondiente
    val queryLimit =  pricesOverLimit.writeStream
      .outputMode("complete")
      .format("console")
      .foreach(new ForeachWriter[Row] {

        override def process(row: Row): Unit = {
          println(s"Over limit ${row}")
          import irm.practica.utils.mail._
          send message s"Prices too high in ${row.getString(0)} "

        }

        override def close(errorOrNull: Throwable): Unit = {}

        override def open(partitionId: Long, version: Long): Boolean = {
          true
        }
      })
      .start

    // Esta tarea se ejecuta a los 25 segundos del inicio de ejecucion y copia un fichero json que hace que la media de la localidad de Lockwood se dispare
    val t = new java.util.Timer()
    val taskCopyDataSetOverLimit = new java.util.TimerTask {
      def run() = {
        println("Nuevos datos...")

        val realEstateDF = spark.read
          .option("header",true)
          .option("sep",",")
          .option("inferschema",true)
          .csv(Utils.pathRealEstateCSVFile)

        // con esta funcion haremos trim del campo Location
        val trimFieldUDF = udf[String, String]((e:String) => e.trim)
        // con esta funcion pasamos pies a metros
        val feetToMetersUDF = udf[Double, Double]((e:Double) => e / 10.764)
        // ahora vamos a hacer uns funcion para pasar el precio de euros a dolares.
        // primero obtemos el valor del cambio EUR -> USD con un API externa que nos proporciona el valor del cambio
        val usdRate = Utils.getExchangeValue()
        // ahora creamos la udf para pasar los dolares a euros
        val usd2eurUDF = udf[Double, Double]((e:Double) => e * usdRate)

        // creamos un data frame con la localizacion trimeada, el tamaño de la vivienda en metros y el precio en EUR
        val realStateCleanedDF = realEstateDF.select(
          trimFieldUDF($"Location").as("Location"),
          feetToMetersUDF($"Size").as("Meters"),
          usd2eurUDF($"Price").as("PriceEUR"))

        realStateCleanedDF.printSchema()

        val shuffledDF = realStateCleanedDF
          .orderBy(rand())
          .limit(5)
          .select($"Location".as("Location"),
                  ($"Meters" / 2).as("Meters"),
                  ($"PriceEUR" * 5).as("PriceEUR"))
        //shuffledDF.show

        // ahora obtenemos un dataframe con la localidad y el precio por m2 en euros
        val realStateValuesDF = shuffledDF.select(
          $"Location",
          ($"PriceEUR" / $"Meters").as("PriceMeter"))
        //realStateValuesDF.show


        val mediaPreciosDF = realStateValuesDF.groupBy($"Location")
          .agg(avg($"PriceMeter").alias("Average_Price_Meter"))
          .orderBy(asc("Location"))

        // procuramos que los datos se queden en una sola partición para que solo se genere un fichero de salida al guardar el dataframe
        val mediaPrecios1PartDF = mediaPreciosDF.coalesce(1)

        // guardamos el contenido del dataframe en formato json
        mediaPrecios1PartDF.write
          .mode(SaveMode.Append)
          .json(Utils.pathRealEstateAvgPricesByLocation)


      }
    }
    t.schedule (taskCopyDataSetOverLimit, 15000L)

    // permitimos la finalización query y queryLimit
    query.awaitTermination()
    queryLimit.awaitTermination()

    spark.stop()

  }
}
