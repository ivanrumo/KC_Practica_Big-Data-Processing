package irm.practica.fase2

import java.io.File

import irm.practica.utils.Utils
import irm.practica.utils.mail.send
import org.apache.commons.io.FileUtils
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, StructType}
import org.apache.spark.sql.{ForeachWriter, Row, SparkSession}

object ReaEstateStreaming {


  def main(args: Array[String]): Unit = {
    // obtenemos el precio limite sobre el que se evalua si se supera para crear una alarma
    var limite:Double = 7000
    if (args.length > 0) {
      limite = args(0).toInt
    }

    // borramos el fichero que sobrepasa el límiteç
    val path = Utils.pathRealEstateAvgPricesByLocation.replaceAll("file://", "")
    val fileName = new File(Utils.pathRealEstateCSVFileOverLimit).getName
    new File(s"${path}/${fileName}").delete()

    val t = new java.util.Timer()
    // Esta tarea se ejecuta a los 25 segundos del inicio de ejecucion y copia un fichero json que hace que la media de la localidad de Lockwood se dispare
    val taskCopyDataSetOverLimit = new java.util.TimerTask {
      def run() = {
        // quitamos el prefijo file:// para que encuentre bien las rutas
        println(s"Copia fichero {Utils.pathRealEstateCSVFileOverLimit}")
        val source = Utils.pathRealEstateCSVFileOverLimit.replaceAll("file://", "")
        val dest = Utils.pathRealEstateAvgPricesByLocation.replaceAll("file://", "")
        FileUtils.copyFileToDirectory(new File(source), new File(dest))
      }
    }
    t.schedule (taskCopyDataSetOverLimit, 25000L)


    // creamos el objeto Spark seccion
    val spark = SparkSession.builder
      .appName("ReaEstateStreaming")
      .master("local[*]")
      .config("spark.sql.streaming.checkpointLocation", Utils.pathRealEstatePricesChekpointStreaming)
      .getOrCreate

    // configuramos el nivel de traza
    Utils.setupLogging()

    // creamos un esquema para los datos de entrada
    val schemaPrices = new StructType()
      .add("Location",StringType, true)
      .add("Average_Price_Meter",DoubleType, true)

    // indicamos el directorio sobre el que proceso tiene que estar escuchando
    val realEstateData = spark.readStream
        .option("header", "true")
        .schema(schemaPrices)
        .json(Utils.pathRealEstateAvgPricesByLocation)

    // Debemos importart spark.implicits paraque funcionen debidamente las conversiones
    import spark.implicits._


    val windowDF = realEstateData.groupBy($"Location", $"Average_Price_Meter", window(current_timestamp(), "1 hour"))
      .count()
      .orderBy($"Average_Price_Meter".desc)

    // en este otro dataframe windowDF las localidades donde el precio medio ha subido por encima del límite
    val pricesOverLimit = windowDF.filter($"Average_Price_Meter" > limite)

    // iniciamos procedimient0 query y mostra mosresultado por consola de modo 'complete'
    val query =  windowDF.writeStream
        .outputMode("complete")
        .format("console")
        .start

    // iniciamos procedimiento queryLimit y realizamos un bucle por cada fila obtenida para mostrar que localidades han superado el limite
    // y mandamos un correo de alerta al departamento correspondiente
    val queryLimit =  pricesOverLimit.writeStream
      .outputMode("complete")
      .format("console")
      .foreach(new ForeachWriter[Row] {

        override def process(row: Row): Unit = {
          println(s"Over limit ${row}")
          import irm.practica.utils.mail._
          send message s"Prices too high in ${row.getString(0)} "

        }

        override def close(errorOrNull: Throwable): Unit = {}

        override def open(partitionId: Long, version: Long): Boolean = {
          true
        }
      })
      .start

    // permitimos la finalización query y queryLimit
    query.awaitTermination()
    queryLimit.awaitTermination()

    spark.stop()

  }
}
