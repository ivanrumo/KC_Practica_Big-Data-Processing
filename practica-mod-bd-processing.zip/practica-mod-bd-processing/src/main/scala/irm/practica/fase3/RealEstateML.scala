package irm.practica.fase3

import java.io.File

import irm.practica.utils.Utils
import org.apache.commons.io.FileUtils
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler}
import org.apache.spark.ml.regression.{LinearRegression, RandomForestRegressor}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf

object RealEstateML {

  def main(args: Array[String]): Unit = {
    // creamos el objeto Spark seccion
    val spark = SparkSession.builder
      .appName("RealEstateML")
      .master("local[*]")
      .getOrCreate

    // configuramos el nivel de traza
    Utils.setupLogging()

    // cargamos el csv con los datos de los precios de productos inmoviliarios
    val realEstateDF = spark.read
      .option("header",true)
      .option("sep",",")
      .option("inferschema",true)
      .csv(Utils.pathRealEstateCSVFile)

    realEstateDF.printSchema

    // indicamos cual es la columna con el dato que queremos predecir
    val labelColumn = "Price"

    // creamos una udf para limpiar los espacios sobrantes en el campo location
    val trimFieldUDF = udf[String, String]((e:String) => e.trim)

    // aplicamos la funcion trimFieldUDF al campo location del dataframe
    import spark.implicits._
    val realEstateCleanedDF = realEstateDF.withColumn("Location", trimFieldUDF($"Location"))

    // obtenemos el conjunto de datos de entrenamiento y el de pruebas
    val Array(trainingData, testData) = realEstateCleanedDF.randomSplit(Array(0.8, 0.2))

    // como Location es una columna texto, tenemos que transformala en un indice. Para ello usamos un StringIndexer
    val locationIndexer = new StringIndexer()
      .setInputCol("Location")
      .setOutputCol("LocationIndex")
      .setHandleInvalid("keep")

    // Con un VectorAssembler juntamos las columnas features en una nueva columna, que denominamos "features", que será un vector
    val assembler = new VectorAssembler()
      .setInputCols(Array("LocationIndex", "Size", "Bedrooms", "Bathrooms"))
      .setOutputCol("features")

    // parametrizamos el algoritmo de Regresion Lineal
    val lr = new LinearRegression()
      .setLabelCol(labelColumn)
      .setFeaturesCol("features")
      .setMaxIter(100)
      .setRegParam(0.5)
      .setElasticNetParam(0.5)

    // creamos un array con las etapas que formaran el Pipeline para entrnar nuestro modelo
    val stages = Array(
      locationIndexer,
      assembler,
      lr
    )

    // creamos el pipeline
    val pipeline = new Pipeline().setStages(stages)

    //Entrenamos nuestro modelo
    val lrModel = pipeline.fit(trainingData)

    // una vez entrenado el modelo, lo probamos con el conjunto de datos de prueba
    val predictionsLR = lrModel.transform(testData).select("features", labelColumn, "prediction")
    predictionsLR.show()
    // borramos el directorio de salida antes de grabar para que no se produzca un error
    FileUtils.deleteDirectory(new File( Utils.pathRealEstateML_LR.replaceAll("file://", "")))
    // grabamos el resultado de las pruebas en un fichero para poder estudiarlo despues
    predictionsLR.write.json(Utils.pathRealEstateML_LR)


    //////////////////////////////////////////////////////////////////////////////////
    //  Ahora vamos a probar con otro algoritmo de predicción: Random Forest Regressor

    // obtenemos el número total de distintos locations para indicarlo porteriormente
    val numClasses = realEstateCleanedDF.select($"Location").distinct().count().toInt

    // parametrizamos el modelo de predicción
    val rf = new RandomForestRegressor()
      .setLabelCol(labelColumn)
      .setFeaturesCol("features")
      .setMaxBins(numClasses)

    // creamos un array con las etapas que formaran el Pipeline para entrnar nuestro modelo
    val stagesRF = Array(
      locationIndexer,
      assembler,
      rf
    )

    // creamos el pipeline
    val pipelineRF = new Pipeline().setStages(stagesRF)

    // Entrenamos nuestro modelo
    val modelRF = pipelineRF.fit(trainingData)

    // una vez entrenado el modelo, lo probamos con el conjunto de datos de prueba
    val predictionsRF = modelRF.transform(testData).select("features", labelColumn, "prediction")
    predictionsRF.show()
    // borramos el directorio de salida antes de grabar para que no se produzca un error
    FileUtils.deleteDirectory(new File( Utils.pathRealEstateML_RF.replaceAll("file://", "")))
    // grabamos el resultado de las pruebas en un fichero para poder estudiarlo despues
    predictionsRF.write.json(Utils.pathRealEstateML_RF)

    spark.stop()
  }
}
