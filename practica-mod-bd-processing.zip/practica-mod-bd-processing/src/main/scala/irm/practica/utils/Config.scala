package irm.practica.utils

import net.liftweb.json._

object Config {
  val pathRealEstatePricesChekpoint = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/checkpoint"
  val pathRealEstateCSVFile = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/datasets/RealEstate.csv"
  val pathRealEstateAvgPricesByLocation = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/real-estate"


  /** Makes sure only ERROR messages get logged to avoid log spam. */
  def setupLogging() = {
    import org.apache.log4j.{Level, Logger}
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
  }

  def getExchangeValue(): Double = {

    val url = "https://api.exchangeratesapi.io/latest"
    val result = scala.io.Source.fromURL(url).mkString

    implicit val formats = DefaultFormats

    val obj = parse(result)
    (obj \ "rates" \ "USD").extract[Double]
  }

}