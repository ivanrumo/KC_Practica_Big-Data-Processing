package irm.practica.utils

import courier._, Defaults._

object mail {

  object send {
    def message(message: String) {
      val mailer = Mailer("smtp.gmail.com", 587)
        .auth(true)
        .as(Utils.myEmail, Utils.myEmailPass)
        .startTls(true)()

      mailer(Envelope.from(Utils.myEmail.addr)
        .to(Utils.emailDest.addr)
        .subject("Avg Price")
        .content(Text(message))).onComplete( {
          case _ => println("message delivered")
        })
    }
  }
}