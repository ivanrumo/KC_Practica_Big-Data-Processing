package irm.practica.utils


import net.liftweb.json._

object Utils {
  // RealEstatePrices parametros de configuracion
  val pathRealEstateCSVFile = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/datasets/RealEstate.csv"
  val pathRealEstateAvgPricesByLocation = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/real-estate"

  // RealEstateStreaming parametros de configuracion
  val pathRealEstatePricesChekpointStreaming = "file:///tmp/checkpoint-streaming"
  val pathRealEstateCSVFileOverLimit = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/datasets/RealEstateStreaming3.json"

  // RealEstateStreamingML parametros de configuracion
  val pathRealEstateML_LR = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/real-estate-ML-LR"
  val pathRealEstateML_RF = "file:///media/ivan/TOSHIBA EXT/BootCamp/Big Data Processing/practica-mod-bd-processing/real-estate-ML-RF"

  // Email
  val myEmail = "micorreo@gmail.com"
  val myEmailPass = "my_password"
  val emailDest = "email_dest@gmail.com"

  /** Makes sure only ERROR messages get logged to avoid log spam. */
  def setupLogging() = {
    import org.apache.log4j.{Level, Logger}
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
  }

  def getExchangeValue(): Double = {

    val url = "https://api.exchangeratesapi.io/latest?symbols=USD"
    val result = scala.io.Source.fromURL(url).mkString

    implicit val formats = DefaultFormats

    val obj = parse(result)
    (obj \ "rates" \ "USD").extract[Double]
  }

}